#importing walmart dataset
dataset = read.csv("Walmart.csv")
# Splitting the Dataset into Training and Testing set
# install.packages("caTools")
install.packages("caTools")
library(caTools)
set.seed(123)
split = sample.split(dataset$Weekly_Sales,SplitRatio = 2/3)
print(split)
training_set = subset(dataset,split==TRUE)
test_set = subset(dataset,split==FALSE)

#Fitting the Simple Linear Regression Model for training set
regressor = lm(formula=Weekly_Sales ~ Store, data=training_set)
print(regressor)                                # printing coefficients of the line.
# Predicting the Test Set Results
y_pred = predict(regressor, newdata = test_set) # predicting the weekely_sales values.
print(y_pred)                                   # printing predicted values.
install.packages("ggplot2")
library(ggplot2)
ggplot() +
  geom_point(aes(x=training_set$Store,
                 y = training_set$Weekly_Sales),
                  color = "red")+
    geom_line(aes(x=training_set$Store,
                  y = predict(regressor,newdata=training_set)),
                  color="blue")+
    ggtitle("Weekly_Sales v/s Store")+
    xlab("Store")+
    ylab("Weekely_Sales")


