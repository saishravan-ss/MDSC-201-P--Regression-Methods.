#importing Start up dataset

dataset = read.csv("50_Startups.csv")
library(caTools)
set.seed(123)
split = sample.split(dataset$Profit, SplitRatio = 2/3)            # splitting the dataset into 2/3 part
print(split)
training_set = subset(dataset, split== TRUE)                      # training set which contains more data than test dataset
test_set = subset(dataset, split == FALSE)
regressor = lm(formula = Profit ~State , data = training_set)     # defining linear model
print(regressor)                                                  # printing coefficients of the line.
y_pred = predict(regressor, newdata = test_set)                   # predicting the weekely_sales values.
print(y_pred)                                                     # printing predicted values.
library(ggplot2)                                                  # importing ggplot library
ggplot() +
  geom_point(aes(x=training_set$State,
                 y = training_set$Profit),
             color = "red")+
  geom_line(aes(x=training_set$State,
                y = predict(regressor,newdata=training_set)),
            color="blue")+
  ggtitle("Profit v/s State")+
  xlab("State")+                                                 # x label
  ylab("Profit")                                                 # y label
